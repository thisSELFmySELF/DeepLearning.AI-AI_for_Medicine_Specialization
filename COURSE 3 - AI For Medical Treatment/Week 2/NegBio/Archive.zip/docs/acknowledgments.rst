Acknowledgments
---------------

This work was supported by the Intramural Research Programs of the National Institutes of Health, National Library of
Medicine and Clinical Center.

We are grateful to the authors of NegEx, MetaMap, Stanford CoreNLP, Bllip parser, and CheXpert labeler for making
their software tools publicly available.

We thank Dr. Alexis Allot for the helpful discussion.
