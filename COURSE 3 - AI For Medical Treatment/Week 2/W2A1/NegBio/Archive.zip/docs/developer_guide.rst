NegBio Developer Guide
======================

Create the documentation
^^^^^^^^^^^^^^^^^^^^^^^^

Install Sphinx

.. code-block:: bash
   :linenos:

   $ pip install Sphinx
   $ pip install sphinx_rtd_theme
   $ cd docs
   $ make html